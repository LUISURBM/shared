  /************************************************************************
   %BodyProcName%
   Created: %DateTime% by %UserName%
   Purpose:
  ************************************************************************/
  MEMBER PROCEDURE %BodyProcName%%BodyProcParams% IS
    tmpVar NUMBER;
  BEGIN
    tmpVar := 0;
  END %BodyProcName%;

